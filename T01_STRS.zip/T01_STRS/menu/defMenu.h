#define ID_MYMENU       10

#define IDM_FILE_OPEN   1
#define IDM_FILE_CLOSE  2
#define IDM_FILE_EXIT   3

#define IDM_VIEW_SWITCH 4
